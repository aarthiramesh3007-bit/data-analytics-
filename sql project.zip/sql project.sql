select * from movies;

select * from directors;

select count(*) from movies;

select * from directors
where name in ('james cameron','luc besson','john woo');

select * from directors
where name like 's%';

select count(*) directors
where gender = 'female';

describe directors;

select count(*) from directors
where gender = 'Female';

select name 
from directors
where gender = 'Female' limit 10;

select * from movies
order by popularity desc limit 3;

select * from movies
order by revenue desc limit 3;

describe movies;

select title, vote_average, release_date
from movies
where release_date >='2000-01-01'
order by vote_average desc
limit 1; 

select m.title
from movies m join directors d on m.director_id = d.id
where d.name = 'brenda chapman';

select m. * from movies
m join directors d on m.director_id= d.id 
where d.name = 'brenda chapman';

select * from directors 
where name like '%brenda%';

select title from movies
where director_id ='4801';

select * from movies limit 5;

select * from directors 
where name ='brenda chapman';

select d.name, count(*) as total_movies
from movies m join directors d on m.director_id = d.id
order by total_movies desc limit 1;

select count(*) from movies;

select director_id, count(*) as total_movies
from movies 
group by director_id
order by total_movies desc;

SELECT directors.name, COUNT(*) AS MoviesCount
FROM movies
JOIN directors
ON movies.director_id = directors.id
GROUP BY directors.name
ORDER BY MoviesCount DESC
LIMIT 1;

SELECT directors.name, movies.original_title, movies.revenue
FROM movies
JOIN directors
ON movies.director_id = directors.id
ORDER BY movies.revenue DESC
LIMIT 1;